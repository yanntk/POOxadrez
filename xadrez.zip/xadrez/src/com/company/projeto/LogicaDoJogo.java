package com.company.projeto;

public class LogicaDoJogo {
    public void iniciarJogo() {
        // Lógica para iniciar o jogo de xadrez
    }

    public static void main(String[] args) {
        // Teste da lógica do jogo
        LogicaDoJogo logicaDoJogo = new LogicaDoJogo();
        logicaDoJogo.iniciarJogo();
    }
}
