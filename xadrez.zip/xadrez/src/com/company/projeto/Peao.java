package com.company.projeto;

public class Peao extends Peca {
    public Peao(Cor cor) {
        super(cor);
    }

    // Implementação específica para o peão, como verificar movimentos válidos, etc.
}
