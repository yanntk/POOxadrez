package com.company.projeto;

public class Peca {
    private Cor cor;

    public Peca(Cor cor) {
        this.cor = cor;
    }

    public Cor getCor() {
        return cor;
    }
}

    // Métodos abstratos para verificar movimentos válidos, etc.


// Implemente outras classes para as outras peças (torre, cavalo, bispo, rainha, rei)
