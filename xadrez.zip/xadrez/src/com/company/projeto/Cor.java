package com.company.projeto;

public enum Cor {
    BRANCO,
    PRETO
}
