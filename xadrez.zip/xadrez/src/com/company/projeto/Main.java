package com.company.projeto;

public class Main {
    public static void main(String[] args) {
        GUIChess guiChess = new GUIChess(); //  instância da classe GUIChess
    }
}




